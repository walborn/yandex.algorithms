const {getHashByData, fetchData} = require('./utils');

module.exports = async function(urls, retryCount) {
    // code here
}
